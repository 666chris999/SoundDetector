package sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Scanner;
import javax.sound.sampled.*;

import javax.mail.*;
import javax.mail.internet.*;

public class Main extends Application {
    //CLIENT INFO
    private String micName;
    private String depName;
    private String mailValue;
    private String mailAdress;

    private ArrayList<String> existingDeps;

    //TO INSERT
    private int depIDFromDB; //LocationID kiderítéséhez
    private int locationIDFromDB; //RecordsNew inserthez

    //BACKGROUNDS
    private Background oneColorBG;
    private Background mainMenuBG;
    private Background recBG;
    {
        try {
            oneColorBG = new Background(new BackgroundImage(new Image(new FileInputStream(new File("1ColorBG.jpg"))),
                BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,null,null));
            mainMenuBG = new Background(new BackgroundImage(new Image(new FileInputStream(new File("mainBG.jpg"))),
                    BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,null,null));
            recBG = new Background(new BackgroundImage(new Image(new FileInputStream(new File("CB1ColorBG.jpg"))),
                    BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,null,null));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //SCENES
    private Scene mainMenuScene;
    private Scene recordScene;
    private Scene statGenScene;
    private Scene settingsScene;

    private ArrayList<Scene> statScenes;
    private int statSceneIndexer = 0;

    //CONTROLLERS
    private boolean isRecording = false;
    private boolean saveData = false;
    private boolean sendAlarmMail = false;

    private Stage primaryStageRef;

    //ETC
    private File settFile;
    private Connection con;

    //FILE HANDLING FUNCTIONS
    private void readSett() throws IOException {
        Scanner fsc = new Scanner(settFile);

        if(fsc.hasNextLine()) {
            micName = fsc.nextLine();
            depName = fsc.nextLine();
            mailValue = fsc.nextLine();
            mailAdress = fsc.nextLine();
            String tempSave = fsc.nextLine();
            String tempAlarm = fsc.nextLine();
            if(tempSave.equals("1")){
                saveData = true;
            }
            if(tempAlarm.equals("1")){
                sendAlarmMail = true;
            }
        }else{
            micName = "";
            depName = "";
            mailValue = "";
            mailAdress = "";
        }

        fsc.close();
    }

    private void writeSett() throws IOException {
        PrintWriter pw = new PrintWriter(settFile);
        pw.println(micName);
        pw.println(depName);
        pw.println(mailValue);
        pw.println(mailAdress);

        if(saveData){
            pw.println("1");
        }else{
            pw.println("0");
        }

        if(sendAlarmMail){
            pw.println("1");
        }else{
            pw.println("0");
        }

        pw.close();
    }

    //CHART GEN FUNCTIONS
    private XYChart.Series seriesGen(LinkedList<Integer> data) {
        XYChart.Series series = new XYChart.Series();

        for (int i = 0; i < data.size(); i++) {
            series.getData().add(new XYChart.Data((double) i , data.get(i)));
        }

        return series;
    }

    private LineChart<Number,Number> lineChartGen(){
        final NumberAxis xAxis = new NumberAxis("Time(sec)",0,120,4);
        final NumberAxis yAxis = new NumberAxis("Volume",2048,4096,128);

        final LineChart<Number,Number> lineChart = new LineChart<>(xAxis,yAxis);
        lineChart.getStylesheets().add(getClass().getResource("recCSS.css").toExternalForm());
        lineChart.setTitle("Sound volume Visualized");
        lineChart.setScaleX(0.85);
        lineChart.setScaleY(0.85);

        return lineChart;
    }

    private BarChart<String,Number> barChartGenStat(
            String chartType, ArrayList<Double> tempValue, ArrayList<String> tempDeps){

        BarChart<String,Number> ret;
        final CategoryAxis xAxis = new CategoryAxis();
        xAxis.setTickLabelsVisible(false);

        final NumberAxis yAxis = new NumberAxis();

        ret = new BarChart<>(xAxis,yAxis);
        ret.setTitle(chartType);
        ret.setScaleX(0.85);
        ret.setScaleY(0.85);

        for(int i=0;i<tempValue.size();i++){
            XYChart.Series tempSeries = new XYChart.Series();
            tempSeries.setName(tempDeps.get(i));
            tempSeries.getData().add(new XYChart.Data(tempDeps.get(i),tempValue.get(i)));
            ret.getData().add(tempSeries);
        }

        return ret;
    }

    private LineChart<Number,Number> lineChartGenStat(
            String chartType, ArrayList<Integer> tempValue, ArrayList<String> tempTimes, ArrayList<String> tempDeps){

        LineChart<Number,Number> ret;
        final NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("From " + tempTimes.get(0).split(" ")[1].split("\\.")[0]
                + " to " + tempTimes.get(tempTimes.size()-1).split(" ")[1].split("\\.")[0] + " (in minutes)");
        final NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Values");

        ret = new LineChart<>(xAxis,yAxis);
        ret.setTitle(chartType);
        ret.setScaleX(0.85);
        ret.setScaleY(0.85);

        ArrayList<String> onePieceDepList = new ArrayList<>();

        for(int i=0;i<tempDeps.size();i++){
            if(!onePieceDepList.contains(tempDeps.get(i))){
                onePieceDepList.add(tempDeps.get(i));
            }
        }

        String[] splittedTimeZero = tempTimes.get(0).split(" ")[1].split(":");
        int dayMinsZero = (int)Math.round((Integer.valueOf(splittedTimeZero[0])*3600+Integer.valueOf(splittedTimeZero[1])*60+
                (int)Math.floor(Double.valueOf(splittedTimeZero[2])))/60.0);

        for(int i=0;i<onePieceDepList.size();i++){
            XYChart.Series tempSeries = new XYChart.Series();
            tempSeries.setName(onePieceDepList.get(i));
            for(int j=0;j<tempValue.size();j++){
                if(tempDeps.get(j).equals(onePieceDepList.get(i))){
                    String[] splittedTime = tempTimes.get(j).split(" ")[1].split(":");
                    int dayMins = (int)Math.round((Integer.valueOf(splittedTime[0])*3600+Integer.valueOf(splittedTime[1])*60+
                            (int)Math.floor(Double.valueOf(splittedTime[2])))/60.0);
                    System.out.println(tempTimes.get(j));
                    tempSeries.getData().add(new XYChart.Data(dayMins-dayMinsZero,tempValue.get(j)));
                };
            }

            ret.getData().add(tempSeries);
        }

        return ret;
    }

    //OTHER FUNCTIONS
    private int getValueFromMic(){
        TargetDataLine targetDataLine;
        byte[] tempBuffer = new byte[4096];
        int inputData;

        //Format definition
        AudioFormat audioFormat = new AudioFormat(8192.0F, 16, 1, true, false);
        DataLine.Info dataLineInfo = new DataLine.Info(TargetDataLine.class, audioFormat);

        try {
            targetDataLine = (TargetDataLine) AudioSystem.getLine(dataLineInfo);
            targetDataLine.open(audioFormat);
            targetDataLine.start();
            targetDataLine.read(tempBuffer, 0, tempBuffer.length);
            inputData = 0;
            for (int i = 0; i < tempBuffer.length; i++) {
                if (tempBuffer[i] != 0) {
                    inputData++;
                }
            }

            //System.out.println(inputData);
            targetDataLine.stop();
            targetDataLine.close();

            return inputData;

        } catch (StringIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        } catch(LineUnavailableException ex){
            ex.printStackTrace();
        }

        return -1;
    }

    private void buttonSetter(Button butt, int pixWidth, int pixHeight, int pixLocHor, int pixLocVer, Image buttImg){
        butt.setMinHeight(pixHeight);
        butt.setMinWidth(pixWidth);
        butt.setMaxHeight(pixHeight);
        butt.setMaxWidth(pixWidth);
        butt.relocate(pixLocHor, pixLocVer);
        butt.setBackground(new Background(new BackgroundImage(buttImg, BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,null,null)));
    }

    private Background imageToBg(Image temp){
        return new Background(new BackgroundImage(temp, BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,null,null));
    }

    private static Connection setUpDb(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection temp = DriverManager.getConnection("jdbc:sqlserver://193.6.33.140:1433;databaseName=BanyatankDB;" +
                    "user=banyatank;password=Banyatank_1");
            System.out.println("Connected successfully");

            return temp;
        } catch(Exception sqlException) {
            sqlException.printStackTrace();

            return null;
        }
    }

    private void setMetaData() throws SQLException {
        Statement sm = con.createStatement();
        ResultSet rs =  sm.executeQuery("select * from Departments where DepName ='" + depName + "';");

        depIDFromDB = 0;
        while(rs.next()){
            depIDFromDB = rs.getInt("DepID");
        }

        if(depIDFromDB != 0){
            ArrayList<String> micNamesFromDb = new ArrayList<>();
            ArrayList<Integer> locIDSFromDb = new ArrayList<>();

            rs = sm.executeQuery("select * from Locations where DepID ='" + depIDFromDB + "';");
            while(rs.next()){
                micNamesFromDb.add(rs.getString("Location_name"));
                locIDSFromDb.add(rs.getInt("LocationID"));
            }

            boolean micFound = false;

            for(int i=0;i<micNamesFromDb.size();i++){
                if(micNamesFromDb.get(i).equals(micName)){
                    micFound=true;
                    locationIDFromDB = locIDSFromDb.get(i);
                }
            }

            if(micFound){
                System.out.println("Found: " + locationIDFromDB + " : " + micName);
            }else{
                Statement onlyMicInsert = con.createStatement();
                onlyMicInsert.executeUpdate(
                        "insert into Locations (Location_name,DepID) values ('" + micName + "','" + depIDFromDB + "');");
                System.out.println("Mic added to DB");
            }
        }else{
            Statement depInsert = con.createStatement();
            depInsert.executeUpdate("insert into Departments(DepName)values ('"+ depName + "');");

            int depIDToAddMic = 0;

            Statement depIdSelect = con.createStatement();
            ResultSet depIdRs = depIdSelect.executeQuery("select * from Departments where DepName='" + depName + "';");
            depIdRs.next();
            depIDToAddMic = depIdRs.getInt("DepID");

            Statement micInsertFromSelect = con.createStatement();
            micInsertFromSelect.executeUpdate(
                    "insert into Locations (Location_name,DepID) values ('" + micName + "','" + depIDToAddMic + "');");

            System.out.println("DEP and MIC added to DB");
        }
    }

    private void alarmMailSender() throws Exception {
        Properties mailServerProperties;
        Session getMailSession;
        MimeMessage generateMailMessage;

        // Step1
        mailServerProperties = System.getProperties();
        mailServerProperties.put("mail.smtp.port", "587");
        mailServerProperties.put("mail.smtp.auth", "true");
        mailServerProperties.put("mail.smtp.starttls.enable", "true");
        System.out.println("Mail Server Properties have been setup successfully..");

        // Step2
        getMailSession = Session.getDefaultInstance(mailServerProperties, null);
        generateMailMessage = new MimeMessage(getMailSession);
        generateMailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("tobakor112@gmail.com"));
        generateMailMessage.setSubject("ALARM!!!");
        String emailBody = "Suspicious Activity at the Office";
        generateMailMessage.setContent(emailBody, "text/html");
        System.out.println("Mail Session has been created successfully..");

        // Step3
        Transport transport = getMailSession.getTransport("smtp");

        // if you have 2FA enabled then provide App Specific Password
        transport.connect("smtp.gmail.com", "alarmforszoftfejl@gmail.com", "@asdalarm");
        transport.sendMessage(generateMailMessage, generateMailMessage.getAllRecipients());
        transport.close();
        System.out.println("Mail Sent successfully");
    }

    private void setExistingDeps() throws SQLException {
        existingDeps = new ArrayList<>();
        Statement sm = con.createStatement();
        ResultSet rs =  sm.executeQuery("select * from Departments;");

        while(rs.next()){
            existingDeps.add(rs.getString("DepName"));
        }
    }

    private Slider sliderGen(){
        Slider temp = new Slider();
        temp.setMin(0);
        temp.setMax(100);
        temp.setMajorTickUnit(10);
        temp.setValue(50);
        temp.setPrefSize(300,75);
        temp.setShowTickLabels(true);
        temp.setShowTickMarks(true);

        return temp;
    }

    private ArrayList<String> LWFetcher(ListView<CheckBox> temp){
        ArrayList<String> retArr = new ArrayList<>();

        for(int i=0;i<temp.getItems().size();i++){
            if(temp.getItems().get(i).isSelected()){
                retArr.add(temp.getItems().get(i).getText());
            }
        }

        return retArr;
    }

    private void requestGenerator(double qpSliderValue, ListView<CheckBox> QPList, double lpSliderValue, ListView<CheckBox> LPList,
                                  ListView<CheckBox> avgList, ListView<CheckBox> minList, ListView<CheckBox> maxList) throws SQLException {

        ArrayList<String> queryQueue = new ArrayList<>();

        //FetchLists
        ArrayList<String> qpFetched = LWFetcher(QPList);
        ArrayList<String> lpFetched = LWFetcher(LPList);
        ArrayList<String> avgFetched = LWFetcher(avgList);
        ArrayList<String> minFetched = LWFetcher(minList);
        ArrayList<String> maxFetched = LWFetcher(maxList);

        StringBuilder qpQuery = new StringBuilder();
        StringBuilder lpQuery = new StringBuilder();
        StringBuilder avgQuery = new StringBuilder();
        StringBuilder minQuery = new StringBuilder();
        StringBuilder maxQuery = new StringBuilder();



        if(qpFetched.size() != 0){
            qpQuery.append("QP,");
            complicatedReqGen(qpSliderValue, queryQueue, qpFetched, qpQuery);
        }

        if(lpFetched.size() != 0){
            lpQuery.append("LP,");
            complicatedReqGen(lpSliderValue, queryQueue, lpFetched, lpQuery);
        }

        if(avgFetched.size() != 0){
            avgQuery.append("AVG,");
            simpleReqGen(queryQueue, avgFetched, avgQuery);
        }

        if(minFetched.size() != 0){
            minQuery.append("MIN,");
            simpleReqGen(queryQueue, minFetched, minQuery);
        }

        if(maxFetched.size() != 0){
            maxQuery.append("MAX,");
            simpleReqGen(queryQueue, maxFetched, maxQuery);
        }

        for(int i=0;i<queryQueue.size();i++){
            System.out.println(queryQueue.get(i));
        }

        statSceneGen(queryQueue);
    }

    private void complicatedReqGen(double tempSliderValue, ArrayList<String> tempQueue, ArrayList<String> tempFetched, StringBuilder tempQuery) {
        if(tempFetched.contains("--All--")){
            tempQuery.append("ALL,");
        }else{
            for(int i = 0; i< tempFetched.size(); i++){
                if(i< tempFetched.size()-1){
                    tempQuery.append(tempFetched.get(i)+"/");
                }else{
                    tempQuery.append(tempFetched.get(i) + ",");
                }
            }
        }

        tempQuery.append((int)Math.floor(tempSliderValue));
        tempQueue.add(tempQuery.toString());
    }

    private void simpleReqGen(ArrayList<String> tempQueue, ArrayList<String> tempFetched, StringBuilder tempQuery) {
        if(tempFetched.contains("--All--")){
            tempQuery.append("ALL");
        }else{
            for(int i = 0; i< tempFetched.size(); i++){
                if(i< tempFetched.size()-1){
                    tempQuery.append(tempFetched.get(i)+"/");
                }else{
                    tempQuery.append(tempFetched.get(i));
                }
            }
        }

        tempQueue.add(tempQuery.toString());
    }

    //SCENE SETTING FUNCTIONS
    private Scene mainMenuSetter (Stage primaryStage) throws Exception {
        Pane layout = new Pane();
        layout.setBackground(mainMenuBG);
        Scene temp = new Scene(layout, 1024, 768);

        //Adding buttons
        Button startRec = new Button();
        Button statGen = new Button();
        Button exit = new Button();
        layout.getChildren().add(startRec);
        layout.getChildren().add(statGen);
        layout.getChildren().add(exit);

        Button settings = new Button();
        layout.getChildren().add(settings);

        //Setting up button properties
        Image startRecImg = new Image(new FileInputStream(new File("startRecImg.png")));
        Image startRecImgHover = new Image(new FileInputStream(new File("startRecImgHover.png")));
        buttonSetter(startRec, 256,48,80,470,startRecImg);
        Image statGenImg = new Image(new FileInputStream(new File("statGenImg.png")));
        Image statGenImgHover = new Image(new FileInputStream(new File("statGenImgHover.png")));
        buttonSetter(statGen, 256,48,80,518, statGenImg);
        Image exitImg = new Image(new FileInputStream(new File("exitImg.png")));
        Image exitImgHover = new Image(new FileInputStream(new File("exitImgHover.png")));
        buttonSetter(exit,256,48, 80,578, exitImg);

        Image settingsImg = new Image(new FileInputStream(new File("settingsImg.png")));
        Image settingsImgHover = new Image(new FileInputStream(new File("settingsImgHover.png")));
        buttonSetter(settings,32,32, 980,12, settingsImg);

        //Functions for buttons

        //START REC
        startRec.setOnMouseClicked(e -> primaryStage.setScene(recordScene));
        startRec.setOnMouseEntered(e -> startRec.setBackground(imageToBg(startRecImgHover)));
        startRec.setOnMouseExited(e -> startRec.setBackground(imageToBg(startRecImg)));

        //STAT GEN
        statGen.setOnMouseClicked(e -> primaryStage.setScene(statGenScene));
        statGen.setOnMouseEntered(e -> statGen.setBackground(imageToBg(statGenImgHover)));
        statGen.setOnMouseExited(e -> statGen.setBackground(imageToBg(statGenImg)));

        //EXIT
        exit.setOnMouseEntered(e -> exit.setBackground(imageToBg(exitImgHover)));
        exit.setOnMouseExited(e -> exit.setBackground(imageToBg(exitImg)));
        exit.setOnMouseClicked(e -> primaryStage.close());

        //SETTINGS
        settings.setOnMouseClicked(e -> primaryStage.setScene(settingsScene));
        settings.setOnMouseEntered(e -> settings.setBackground(imageToBg(settingsImgHover)));
        settings.setOnMouseExited(e -> settings.setBackground(imageToBg(settingsImg)));

        return temp;
    }

    private Scene recordSetter(Stage primaryStage) throws Exception {
        StackPane layout = new StackPane();
        layout.setBackground(recBG);
        Scene temp = new Scene(layout,1024,834);

        LineChart<Number, Number> recChart = lineChartGen();
        recChart.setAnimated(false);
        recChart.setLegendVisible(false);
        recChart.setCreateSymbols(false);
        layout.setAlignment(recChart,Pos.BASELINE_CENTER);
        layout.getChildren().add(recChart);

        //...

        Button recButt = new Button();
        Image startRecImg = new Image(new FileInputStream(new File("startRecImg.png")));
        Image startRecImgHover = new Image(new FileInputStream(new File("startRecImgHover.png")));
        buttonSetter(recButt, 256,48,0,0,startRecImg);

        Button stopButt = new Button();
        Image stopRecImg = new Image(new FileInputStream(new File("stopRecImg.png")));
        Image stopRecImgHover = new Image(new FileInputStream(new File("stopRecImgHover.png")));
        buttonSetter(stopButt, 256,48,0,0,stopRecImg);

        Button backToMenu = new Button();
        Image BTMImg = new Image(new FileInputStream(new File("backToMainImg.png")));
        Image BTMImgHover = new Image(new FileInputStream(new File("backToMainImgHover.png")));
        buttonSetter(backToMenu, 256,48,0,0,BTMImg);


        layout.getChildren().add(recButt);
        layout.getChildren().add(stopButt);
        layout.getChildren().add(backToMenu);
        layout.setAlignment(recButt,Pos.BOTTOM_LEFT);
        layout.setAlignment(stopButt,Pos.BOTTOM_CENTER);
        layout.setAlignment(backToMenu,Pos.BOTTOM_RIGHT);

        recButt.setOnMouseClicked(e ->{
            Thread graphThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    LinkedList<Integer> audioList = new LinkedList<>();

                    final int[] bufferCounter = {0};
                    final StringBuilder[] queryBuilder = {new StringBuilder()};
                    queryBuilder[0].append("insert into RecordsNew(LocationID,RecValues,Rectime) values ");

                    isRecording=true;
                    while(isRecording){
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                int audioInput = getValueFromMic();
                                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                                //System.out.println(timestamp);

                                if(audioList.size()<121){
                                    audioList.addFirst(audioInput);
                                }else {
                                    audioList.removeLast();
                                    audioList.addFirst(audioInput);
                                }

                                XYChart.Series<Number,Number> mainSeries = seriesGen(audioList);

                                if(saveData) {
                                    bufferCounter[0]++;
                                    if (bufferCounter[0] == 20) {
                                        queryBuilder[0].append("('" + locationIDFromDB + "','" + audioInput + "','" + timestamp.toString() + "');");
                                        try {
                                            Statement sm = con.createStatement();
                                            sm.executeUpdate(queryBuilder[0].toString());
                                            queryBuilder[0] = new StringBuilder();
                                            queryBuilder[0].append("insert into RecordsNew(LocationID,RecValues,RecTime) values ");

                                            bufferCounter[0] = 0;
                                        } catch (SQLException e1) {
                                            e1.printStackTrace();
                                        }
                                    } else {
                                        queryBuilder[0].append("('" + locationIDFromDB + "','" + (float) audioInput + "','" + timestamp.toString() + "'),");
                                    }
                                }

                                if(sendAlarmMail && Integer.valueOf(mailValue)<audioInput){
                                    try {
                                        alarmMailSender();
                                    } catch (Exception e1) {
                                        e1.printStackTrace();
                                    }
                                }

                                try {
                                    recChart.getData().clear();
                                    recChart.getData().add(mainSeries);
                                } catch (Exception e1) {
                                    e1.printStackTrace();
                                }
                            }
                        });

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
            });
            graphThread.start();
        });

        recButt.setOnMouseEntered(e -> recButt.setBackground(imageToBg(startRecImgHover)));

        recButt.setOnMouseExited(e -> recButt.setBackground(imageToBg(startRecImg)));

        stopButt.setOnMouseClicked(e -> isRecording=false);

        stopButt.setOnMouseEntered(e -> stopButt.setBackground(imageToBg(stopRecImgHover)));

        stopButt.setOnMouseExited(e -> stopButt.setBackground(imageToBg(stopRecImg)));

        backToMenu.setOnMouseEntered(e -> backToMenu.setBackground(imageToBg(BTMImgHover)));

        backToMenu.setOnMouseExited(e -> backToMenu.setBackground(imageToBg(BTMImg)));

        backToMenu.setOnMouseClicked(e -> {primaryStage.setScene(mainMenuScene);isRecording=false;});

        return temp;
    }

    private Scene statGenSetter(Stage primaryStage) {
        VBox layout = new VBox();
        layout.setBackground(oneColorBG);
        layout.setAlignment(Pos.TOP_CENTER);
        Scene temp = new Scene(layout,1024,768);
        temp.getStylesheets().add(getClass().getResource("defaultCSS.css").toExternalForm());

        //Title
        Label title = new Label("Statistic Chart Generator");
        title.setId("title");

        //Quiet Period
        HBox QPBox = new HBox();
        QPBox.setAlignment(Pos.CENTER);
        QPBox.setSpacing(5);

        Label QPLabel = new Label("Quiet Periods -");

        Slider QPSlider = sliderGen();

        ArrayList<CheckBox> QPcheckBoxDepList = new ArrayList<>();
        QPcheckBoxDepList.add(new CheckBox("--All--"));
        for(int i=0;i<existingDeps.size();i++){
            QPcheckBoxDepList.add(new CheckBox(existingDeps.get(i)));
        }

        ObservableList<CheckBox> quietPeriodCheckBoxObservableList= FXCollections.observableArrayList(QPcheckBoxDepList);
        ListView<CheckBox> QPList = new ListView<>(quietPeriodCheckBoxObservableList);
        QPList.setMaxHeight(82);
        QPList.setMaxWidth(256);


        QPBox.getChildren().add(QPLabel);
        QPBox.getChildren().add(QPSlider);
        QPBox.getChildren().add(QPList);

        //Loud Period
        HBox LPBox = new HBox();
        LPBox.setAlignment(Pos.CENTER);
        LPBox.setSpacing(5);

        Label LPLabel = new Label("Loud Periods -");

        Slider LPSlider = sliderGen();

        ArrayList<CheckBox> LPcheckBoxDepList = new ArrayList<>();
        LPcheckBoxDepList.add(new CheckBox("--All--"));
        for(int i=0;i<existingDeps.size();i++){
            LPcheckBoxDepList.add(new CheckBox(existingDeps.get(i)));
        }

        ObservableList<CheckBox> loudPeriodCheckBoxObservableList = FXCollections.observableArrayList(LPcheckBoxDepList);
        ListView<CheckBox> LPList = new ListView<>(loudPeriodCheckBoxObservableList);
        LPList.setMaxHeight(82);
        LPList.setMaxWidth(256);


        LPBox.getChildren().add(LPLabel);
        LPBox.getChildren().add(LPSlider);
        LPBox.getChildren().add(LPList);

        //Average
        HBox avgBox = new HBox();
        avgBox.setAlignment(Pos.CENTER);
        avgBox.setSpacing(5);

        Label avgLabel = new Label("Average -");

        ArrayList<CheckBox> avgCheckBoxDepList = new ArrayList<>();
        avgCheckBoxDepList.add(new CheckBox("--All--"));
        for(int i=0;i<existingDeps.size();i++){
            avgCheckBoxDepList.add(new CheckBox(existingDeps.get(i)));
        }

        ObservableList<CheckBox> avgCheckBoxObservableList = FXCollections.observableArrayList(avgCheckBoxDepList);
        ListView<CheckBox> avgList = new ListView<>(avgCheckBoxObservableList);
        avgList.setMaxHeight(82);
        avgList.setMaxWidth(256);


        avgBox.getChildren().add(avgLabel);
        avgBox.getChildren().add(avgList);

        //Min
        HBox minBox = new HBox();
        minBox.setAlignment(Pos.CENTER);
        minBox.setSpacing(5);

        Label minLabel = new Label("Minimum -");

        ArrayList<CheckBox> minCheckBoxDepList = new ArrayList<>();
        minCheckBoxDepList.add(new CheckBox("--All--"));
        for(int i=0;i<existingDeps.size();i++){
            minCheckBoxDepList.add(new CheckBox(existingDeps.get(i)));
        }

        ObservableList<CheckBox> minCheckBoxObservableList = FXCollections.observableArrayList(minCheckBoxDepList);
        ListView<CheckBox> minList = new ListView<>(minCheckBoxObservableList);
        minList.setMaxHeight(82);
        minList.setMaxWidth(256);


        minBox.getChildren().add(minLabel);
        minBox.getChildren().add(minList);

        //Max
        HBox maxBox = new HBox();
        maxBox.setAlignment(Pos.CENTER);
        maxBox.setSpacing(5);

        Label maxLabel = new Label("Maximum -");

        ArrayList<CheckBox> maxCheckBoxDepList = new ArrayList<>();
        maxCheckBoxDepList.add(new CheckBox("--All--"));
        for(int i=0;i<existingDeps.size();i++){
            maxCheckBoxDepList.add(new CheckBox(existingDeps.get(i)));
        }

        ObservableList<CheckBox> maxCheckBoxObservableList = FXCollections.observableArrayList(maxCheckBoxDepList);
        ListView<CheckBox> maxList = new ListView<>(maxCheckBoxObservableList);
        maxList.setMaxHeight(82);
        maxList.setMaxWidth(256);


        maxBox.getChildren().add(maxLabel);
        maxBox.getChildren().add(maxList);

        //Buttons
        HBox buttonBox = new HBox();
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setSpacing(15);

        Button stringGenButt = new Button("Generate Graphs");
        stringGenButt.setId("sg");
        stringGenButt.setOnMouseClicked(
                e -> {
                    try {
                        requestGenerator(QPSlider.getValue(),QPList,LPSlider.getValue(),LPList,avgList,minList,maxList);
                        primaryStage.setScene(statScenes.get(0));
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                });

        Button backToMainButt = new Button("Back");
        backToMainButt.setId("btm");
        backToMainButt.setOnMouseClicked(e -> primaryStage.setScene(mainMenuScene));

        buttonBox.getChildren().add(stringGenButt);
        buttonBox.getChildren().add(backToMainButt);

        //Placeholders
        Label[] phList = {new Label("-"),new Label("-"),
                new Label("-"),new Label("-"),new Label("-"),new Label("-")};

        layout.getChildren().add(new Label());
        layout.getChildren().add(title);
        layout.getChildren().add(phList[0]);
        layout.getChildren().add(QPBox);
        layout.getChildren().add(phList[1]);
        layout.getChildren().add(LPBox);
        layout.getChildren().add(phList[2]);
        layout.getChildren().add(avgBox);
        layout.getChildren().add(phList[3]);
        layout.getChildren().add(minBox);
        layout.getChildren().add(phList[4]);
        layout.getChildren().add(maxBox);
        layout.getChildren().add(phList[5]);
        layout.getChildren().add(buttonBox);

        return temp;
    }

    private Scene settingsSetter(Stage primaryStage) throws IOException {
        VBox VBlayout = new VBox();
        VBlayout.setAlignment(Pos.TOP_CENTER);
        VBlayout.setSpacing(16);
        VBlayout.setPadding(new Insets(50,0,0,0));

        StackPane SPlayout = new StackPane();
        SPlayout.setBackground(oneColorBG);
        SPlayout.getChildren().add(VBlayout);
        Scene temp = new Scene(SPlayout,1024,768);
        temp.getStylesheets().add(getClass().getResource("defaultCSS.css").toExternalForm());

        //Textfields
        Label micIDLabel = new Label("Microphone Name");
        TextField micIDField = new TextField();
        micIDField.setMaxWidth(256);
        micIDField.setText(micName);

        Label depNameLabel = new Label("Department Name");
        TextField depNameField = new TextField();
        depNameField.setMaxWidth(256);
        depNameField.setText(depName);

        Label mailValueLabel = new Label("Alarm Min. Value");
        TextField mailValueField = new TextField();
        mailValueField.setMaxWidth(256);
        mailValueField.setText(mailValue);

        Label mailAdressLabel = new Label("E-mail Adress");
        TextField mailAdressField = new TextField();
        mailAdressField.setMaxWidth(256);
        mailAdressField.setText(mailAdress);

        //CheckBoxes
        CheckBox saveBox = new CheckBox("Save Captured Data");
        CheckBox mailBox = new CheckBox("Send Alarm Mail");

        saveBox.setSelected(saveData);
        mailBox.setSelected(sendAlarmMail);

        //PH Labels
        Label ph1 = new Label("-");
        Label ph2 = new Label("-");


        //BUTTONS
        Button saveButt = new Button();
        Button backButt = new Button();

        Image saveImg = new Image(new FileInputStream(new File("saveImg.png")));
        Image saveImgHover = new Image(new FileInputStream(new File("saveImgHover.png")));
        buttonSetter(saveButt, 256,48,0,0,saveImg);

        Image BTMImg = new Image(new FileInputStream(new File("backToMainImg.png")));
        Image BTMImgHover = new Image(new FileInputStream(new File("backToMainImgHover.png")));
        buttonSetter(backButt, 256,48,0,0,BTMImg);

        backButt.setOnMouseEntered(e->backButt.setBackground(imageToBg(BTMImgHover)));
        backButt.setOnMouseExited(e->backButt.setBackground(imageToBg(BTMImg)));

        saveButt.setOnMouseEntered(e->saveButt.setBackground(imageToBg(saveImgHover)));
        saveButt.setOnMouseExited(e->saveButt.setBackground(imageToBg(saveImg)));

        //ADDING ELEMENTS TO LAYOUT
        VBlayout.getChildren().addAll(micIDLabel,micIDField);
        VBlayout.getChildren().addAll(depNameLabel,depNameField);
        VBlayout.getChildren().addAll(mailValueLabel,mailValueField);
        VBlayout.getChildren().addAll(mailAdressLabel,mailAdressField);
        VBlayout.getChildren().add(ph1);
        VBlayout.getChildren().add(saveBox);
        VBlayout.getChildren().add(mailBox);
        VBlayout.getChildren().add(ph2);
        VBlayout.getChildren().add(saveButt);
        VBlayout.getChildren().add(backButt);

        saveButt.setOnMouseClicked(e-> {
            micName = micIDField.getText();
            depName = depNameField.getText();
            mailValue = mailValueField.getText();
            mailAdress = mailAdressField.getText();

            if(saveBox.isSelected()){
                saveData = true;
            }else{
                saveData = false;
            }

            if(mailBox.isSelected()){
                sendAlarmMail = true;
            }else{
                sendAlarmMail = false;
            }

            try {
                writeSett();

                con = setUpDb();
                setMetaData();

            } catch (IOException e1) {
                e1.printStackTrace();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });

        backButt.setOnMouseClicked(e -> primaryStage.setScene(mainMenuScene));

        return temp;
    }

    private Scene simpleStatSceneGen(Chart tempChart){
        StackPane layout = new StackPane();

        Scene temp = new Scene(layout,1024,834);
        temp.getStylesheets().add(getClass().getResource("defaultCSS.css").toExternalForm());

        HBox buttBox = new HBox();
        buttBox.getStylesheets().add(getClass().getResource("stat.css").toExternalForm());
        buttBox.setSpacing(10);

        Button nextScene = new Button("Next");
        nextScene.setId("nS");
        Button prevScene = new Button("Previous");
        prevScene.setId("pS");
        Button btm = new Button("Back To Main Menu");
        btm.setId("btmS");
        nextScene.setOnMouseClicked(e -> {
            if(statSceneIndexer != statScenes.size()-1){
                statSceneIndexer++;
            }else{
                statSceneIndexer=0;
            }
            primaryStageRef.setScene(statScenes.get(statSceneIndexer));
        });

        prevScene.setOnMouseClicked(e -> {
            if(statSceneIndexer != 0){
                statSceneIndexer--;
            }else{
                statSceneIndexer=statScenes.size()-1;
            }
            primaryStageRef.setScene(statScenes.get(statSceneIndexer));
        });

        btm.setOnMouseClicked(e -> primaryStageRef.setScene(mainMenuScene));

        buttBox.getChildren().addAll(prevScene,nextScene,btm);
        buttBox.setAlignment(Pos.BOTTOM_CENTER);

        layout.setBackground(recBG);
        layout.getChildren().add(tempChart);
        layout.getChildren().add(buttBox);

        return temp;
    }

    private void statSceneGen(ArrayList<String> reqStringArr) throws SQLException {
        statScenes = new ArrayList<>();

        ArrayList<Scene> tempScenes = new ArrayList<>();

        ArrayList<Integer> QPValues = new ArrayList<>();
        ArrayList<String> QPTimes = new ArrayList<>();
        ArrayList<String> QPDeps = new ArrayList<>(); // Actual department

        ArrayList<Integer> LPValues = new ArrayList<>();
        ArrayList<String> LPTimes = new ArrayList<>();
        ArrayList<String> LPDeps = new ArrayList<>(); // Actual department

        ArrayList<Double> avgValues = new ArrayList<>();
        ArrayList<String> avgDeps = new ArrayList<>();

        ArrayList<Double> minValues = new ArrayList<>();
        ArrayList<String> minDeps = new ArrayList<>();

        ArrayList<Double> maxValues = new ArrayList<>();
        ArrayList<String> maxDeps = new ArrayList<>();

        for(int i=0;i<reqStringArr.size();i++){
            Statement smNQ = con.createStatement();
            Statement smQ = con.createStatement();
            smNQ.executeUpdate("insert into Request values ('"+reqStringArr.get(i) + "','"
                    + new Timestamp(System.currentTimeMillis()).toString() + "');");

            ResultSet rs =  smQ.executeQuery("select * from Output_Table;");

            switch(reqStringArr.get(i).split(",")[0]){
                case "QP":
                    while(rs.next()){
                        QPValues.add(rs.getInt("RecValues"));
                        QPTimes.add(rs.getString("Rectime"));
                        QPDeps.add(rs.getString("DepName"));
                    }
                    statScenes.add(simpleStatSceneGen(lineChartGenStat("Quiet Period", QPValues, QPTimes, QPDeps)));
                    break;
                case "LP":
                    while(rs.next()){
                        LPValues.add(rs.getInt("RecValues"));
                        LPTimes.add(rs.getString("Rectime"));
                        LPDeps.add(rs.getString("DepName"));
                    }
                    statScenes.add(simpleStatSceneGen(lineChartGenStat("Loud Period", LPValues, LPTimes, LPDeps)));
                    break;
                case "AVG":
                    while(rs.next()) {
                        avgValues.add(rs.getDouble("AverageValues"));
                        avgDeps.add(rs.getString("DepName"));
                    }
                    statScenes.add(simpleStatSceneGen(barChartGenStat("Average", avgValues, avgDeps)));
                    break;
                case "MIN":
                    while(rs.next()) {
                        minValues.add(rs.getDouble("MinValues"));
                        minDeps.add(rs.getString("DepName"));
                    }
                    statScenes.add(simpleStatSceneGen(barChartGenStat("Minimum", minValues, minDeps)));
                    break;
                case "MAX":
                    while(rs.next()) {
                        maxValues.add(rs.getDouble("MaxValues"));
                        maxDeps.add(rs.getString("DepName"));
                    }
                    statScenes.add(simpleStatSceneGen(barChartGenStat("Maximum", maxValues, maxDeps)));
                    break;
            }
        }

        System.out.println("--QP--");
        for(int i=0;i<QPValues.size();i++){
            System.out.println(QPValues.get(i) + " " + QPTimes.get(i) + " " + QPDeps.get(i));
        }

        System.out.println("--LP--");
        for(int i=0;i<LPValues.size();i++){
            System.out.println(LPValues.get(i) + " " + LPTimes.get(i) + " " + LPDeps.get(i));
        }

        System.out.println("--AVG--");
        for(int i=0;i<avgValues.size();i++){
            System.out.println(avgValues.get(i) + " " + avgDeps.get(i));
        }

        System.out.println("--MIN--");
        for(int i=0;i<minValues.size();i++){
            System.out.println(minValues.get(i) + " " + minDeps.get(i));
        }

        System.out.println("--MAX--");
        for(int i=0;i<maxValues.size();i++){
            System.out.println(maxValues.get(i) + " " + maxDeps.get(i));
        }
    }


    @Override
    public void start(Stage primaryStage) throws Exception{
        //CREATE/LOAD SETTINGS FILE
        settFile = new File("settings.txt");
        settFile.createNewFile();
        readSett();

        con = setUpDb();

        setMetaData();
        setExistingDeps();
        primaryStageRef=primaryStage;

        //SETTING SCENES
        mainMenuScene = mainMenuSetter(primaryStage);
        recordScene = recordSetter(primaryStage);
        statGenScene = statGenSetter(primaryStage);
        settingsScene = settingsSetter(primaryStage);

        //SETTING PRIMARYSTAGE ATTRIBUTES
        primaryStage.setScene(mainMenuScene);
        primaryStage.sizeToScene();
        primaryStage.setResizable(false);
        primaryStage.setTitle("Office Noise Analyzer");
        primaryStage.show();
    }

    public static void main(String[] args){
        launch(args);
    }
}